// env.d.ts
declare module "@env" {
  export const FLASK_API_URL: string;
}
